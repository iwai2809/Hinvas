<div id="footer_area">
<hr>
<ul class="navi">
<li>3組 2番 岩井瑛斗</li>
</ul>
</div>
<br>
</div>
</body>
</html>